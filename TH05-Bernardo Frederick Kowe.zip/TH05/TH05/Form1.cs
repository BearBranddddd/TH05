﻿using System;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

namespace TH05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        DataTable dtProdukSimpan = new DataTable();
        DataTable dtCategory = new DataTable();
        DataTable filter = new DataTable();
        int category = 5;

        private void Form1_Load(object sender, EventArgs e)
        {
            Bitmap bitmap0 = new Bitmap(pictureBox1.Image);
            var bt = MakeTransparent(bitmap0, Color.White, 5);
            pictureBox1.Image = bt;

            dtProdukSimpan.Columns.Add("ID  Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID \nCategory");

            dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");

            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");

            filter.Columns.Add("ID  Product");
            filter.Columns.Add("Nama Product");
            filter.Columns.Add("Harga");
            filter.Columns.Add("Stock");
            filter.Columns.Add("ID \nCategory");

            dataGridView1.DataSource = dtProdukSimpan;
            dataGridView2.DataSource = dtCategory;
            dataGridView3.DataSource = filter;

            dataGridView1.ClearSelection();
            dataGridView2.ClearSelection();

            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_cat.Items.Add(dtCategory.Rows[i][1]);
            }
        }

        private void b_filter_Click(object sender, EventArgs e)
        {
            cb_filter.Items.Clear();
            cb_filter.Enabled = true;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cb_filter.Items.Add(dtCategory.Rows[i][1]);
            }
        }
        bool c = false;
        private void remove_cat_Click(object sender, EventArgs e)
        {
            if (c == true)
            {
                if (dataGridView3.Visible == true)
                {
                    dataGridView3.Visible = false;
                    dataGridView1.Visible = true;
                }
                string aa = dataGridView2.CurrentRow.Cells[0].Value.ToString();
                string b = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                for (int i = dtProdukSimpan.Rows.Count - 1; i >= 0; i--)
                {
                    if (dtProdukSimpan.Rows[i][4] == aa)
                    {
                        dtProdukSimpan.Rows[i].Delete();
                    }
                }
                for (int i = dtCategory.Rows.Count - 1; i >= 0; i--)
                {
                    if (dtCategory.Rows[i][0] == aa)
                    {
                        dtCategory.Rows[i].Delete();
                    }
                }
                for (int i = 0; i < cb_filter.Items.Count; i++)
                {
                    if (cb_filter.Items[i] == b)
                    {
                        cb_filter.Items.Remove(cb_filter.Items[i]);
                    }
                }
                for (int i = 0; i < cb_cat.Items.Count; i++)
                {
                    if (cb_cat.Items[i] == b)
                    {
                        cb_cat.Items.Remove(cb_cat.Items[i]);
                    }
                }
                c = false;
                tb_addCategory.Text = "";
                dataGridView2.ClearSelection();
                dataGridView1.ClearSelection();
            }
            tb_namaproduk.Text = "";
            tb_hargaproduk.Text = "";
            tb_stok.Text = "";
            cb_cat.Text = "";
            cb_filter.Text = "";
        }

        private void add_cat_Click(object sender, EventArgs e)
        {
            
            int tes = 0;
            if (tb_addCategory.Text == "")
            {
                DialogResult mb = MessageBox.Show("Masukkan Nama Category Terlebih Dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == tb_addCategory.Text)
                    {
                        DialogResult mb = MessageBox.Show("Category Sudah Ada", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                    else
                    {
                        tes++;
                        if (tes == dtCategory.Rows.Count)
                        {
                            if (dataGridView3.Visible == true)
                            {
                                dataGridView3.Visible = false;
                                dataGridView1.Visible = true;
                            }
                            category = Convert.ToInt32(dtCategory.Rows[dtCategory.Rows.Count - 1][0].ToString().Substring(1,1)) + 1;
                            string cat = "C" + (category).ToString();
                            dtCategory.Rows.Add(cat, tb_addCategory.Text);
                            tb_addCategory.Text = "";
                            cb_filter.Items.Clear();
                            for (int j = 0; j < dtCategory.Rows.Count; j++)
                            {
                                cb_filter.Items.Add(dtCategory.Rows[j][1]);

                            }
                            cb_cat.Items.Clear();
                            for (int k = 0; k < dtCategory.Rows.Count; k++)
                            {
                                cb_cat.Items.Add(dtCategory.Rows[k][1]);
                            }
                            tb_namaproduk.Text = "";
                            tb_hargaproduk.Text = "";
                            tb_stok.Text = "";
                            cb_cat.Text = "";
                            cb_filter.Text = "";
                            dataGridView1.ClearSelection();
                            tb_addCategory.Text = "";
                            dataGridView2.ClearSelection();
                            break;
                        }
                        
                    }
                }
            }
            
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_addCategory.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_namaproduk.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            tb_hargaproduk.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            tb_stok.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            for (int j = 0;j < dtCategory.Rows.Count; j++)
            {
                if (dataGridView1.CurrentRow.Cells[4].Value.ToString() == dtCategory.Rows[j][0].ToString())
                {
                    cb_cat.Text = dtCategory.Rows[j][1].ToString();
                    break;
                }
            }
        }
        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            tb_namaproduk.Text = dataGridView3.CurrentRow.Cells[1].Value.ToString();
            tb_hargaproduk.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
            tb_stok.Text = dataGridView3.CurrentRow.Cells[3].Value.ToString();
            for (int j = 0; j < dtCategory.Rows.Count; j++)
            {
                if (dataGridView3.CurrentRow.Cells[4].Value.ToString() == dtCategory.Rows[j][0].ToString())
                {
                    cb_cat.Text = dtCategory.Rows[j][1].ToString();
                    break;
                }
            }
        }
        private void b_removeproduk_Click(object sender, EventArgs e)
        {
            if (a == false)
            {
                if (dataGridView3.Visible == true)
                {
                    dataGridView3.Visible = false;
                    dataGridView1.Visible = true;
                    cb_filter.Text = ""; 
                }
            }
            else
            {
                if (dataGridView1.Visible == true)
                {
                    string ha = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                    int index = 0;
                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (dtProdukSimpan.Rows[i][0].ToString() == ha)
                        {
                            index = i;

                        }
                    }
                    dtProdukSimpan.Rows[index].Delete();
                }
                else if (dataGridView3.Visible == true)
                {
                    string ha = dataGridView3.CurrentRow.Cells[0].Value.ToString();
                    int index = 0;
                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (dtProdukSimpan.Rows[i][0].ToString() == ha)
                        {
                            index = i;

                        }
                    }
                    dtProdukSimpan.Rows[index].Delete();
                    dataGridView3.Visible = false;
                    dataGridView1.Visible = true;
                }
                tb_namaproduk.Text = "";
                tb_hargaproduk.Text = "";
                tb_stok.Text = "";
                cb_cat.Text = "";
                cb_filter.Text = "";
                a = false;
                dataGridView1.ClearSelection();
                tb_addCategory.Text = "";
                dataGridView2.ClearSelection();
            }
        }
        bool a = false;
        private void b_edit_Click(object sender, EventArgs e)
        {
            if (a == false)
            {
                DialogResult mb = MessageBox.Show("Pilih Produk Yang Mau Di Edit Terlebih Dahulu", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                if (dataGridView3.Visible == true)
                {
                    dataGridView3.Visible = false;
                    dataGridView1.Visible = true;
                    cb_filter.Text = "";
                }
                c = false;
                dataGridView2.ClearSelection();
                tb_addCategory.Text = "";
            }
            else
            {
                if (tb_namaproduk.Text == "" || tb_hargaproduk.Text == "" || tb_stok.Text == "")
                {
                    DialogResult mb = MessageBox.Show("Input Yang Bener", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_namaproduk.Text = "";
                    tb_hargaproduk.Text = "";
                    tb_stok.Text = "";
                    cb_cat.Text = "";
                    dataGridView1.ClearSelection();
                    dataGridView2.ClearSelection();
                    if (dataGridView3.Visible == true)
                    {
                        dataGridView3.Visible = false;
                        dataGridView1.Visible = true;
                    }
                    a = false;
                    c = false;
                }
                else if (cb_cat.SelectedIndex == -1)
                {
                    DialogResult mb = MessageBox.Show("Pilih Category Dulu Boy", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    tb_namaproduk.Text = "";
                    tb_hargaproduk.Text = "";
                    tb_stok.Text = "";
                    cb_cat.Text = "";
                    dataGridView1.ClearSelection();
                    dataGridView2.ClearSelection();
                    if (dataGridView3.Visible == true)
                    {
                        dataGridView3.Visible = false;
                        dataGridView1.Visible = true;
                    }
                    a = false;
                    c = false;
                }
                else
                {
                    int index = 0;
                    if (dataGridView1.Visible == true)
                    {
                        string ha = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                        for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                        {
                            if (dtProdukSimpan.Rows[i][1].ToString() == ha)
                            {
                                index = i;
                            }
                        }
                    }
                    else if (dataGridView3.Visible == true)
                    {
                        string ha = dataGridView3.CurrentRow.Cells[1].Value.ToString();
                        for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                        {
                            if (dtProdukSimpan.Rows[i][1].ToString() == ha)
                            {
                                index = i;
                            }
                        }
                        dataGridView1.Visible = true;
                        dataGridView3.Visible = false;
                        cb_filter.Text = "";
                    }

                    if (tb_stok.Text == "0")
                    {
                        dtProdukSimpan.Rows[index].Delete();
                    }
                    else
                    {
                        dtProdukSimpan.Rows[index][1] = tb_namaproduk.Text;
                        dtProdukSimpan.Rows[index][2] = tb_hargaproduk.Text;
                        dtProdukSimpan.Rows[index][3] = tb_stok.Text;
                        for (int i = 0; i < dtCategory.Rows.Count; i++)
                        {
                            if (cb_cat.SelectedItem == dtCategory.Rows[i][1])
                            {
                                dtProdukSimpan.Rows[index][4] = dtCategory.Rows[i][0];
                                break;
                            }
                        }
                    }
                    a = false;
                    tb_namaproduk.Text = "";
                    tb_hargaproduk.Text = "";
                    tb_stok.Text = "";
                    cb_cat.Text = "";
                    dataGridView1.ClearSelection();
                    tb_addCategory.Text = "";
                    dataGridView2.ClearSelection();
                }
            }
        }


        private void b_product_Click(object sender, EventArgs e)
        {
            if(tb_namaproduk.Text == "" || tb_hargaproduk.Text == "" || tb_stok.Text == "")
            {
                DialogResult mb = MessageBox.Show("Input Yang Lengkap Yah", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (cb_cat.SelectedIndex == -1)
            {
                DialogResult mb = MessageBox.Show("Pilih Category Dulu Boy", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (dataGridView3.Visible == true)
                {
                    dataGridView3.Visible = false;
                    dataGridView1.Visible = true;
                }
                dtProdukSimpan.Rows.Add("J002", tb_namaproduk.Text, tb_hargaproduk.Text, tb_stok.Text);
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (cb_cat.SelectedItem == dtCategory.Rows[i][1])
                    {
                        dtProdukSimpan.Rows[dtProdukSimpan.Rows.Count - 1][4] = dtCategory.Rows[i][0];
                        break;
                    }
                }
                int j = dtProdukSimpan.Rows.Count - 1;
                string kode = dtProdukSimpan.Rows[j][1].ToString().Substring(0, 1).ToUpper();
                int code = 1;
                int categ = 0;
                for (int i = dtProdukSimpan.Rows.Count - 2; i >= 0; i--)
                {
                    if (dtProdukSimpan.Rows[i][1].ToString().Substring(0, 1).ToUpper() == kode)
                    {
                        categ = Convert.ToInt32(dtProdukSimpan.Rows[i][0].ToString().Substring(1, 3));
                        code = categ + 1; break;
                    }
                }
                if (code < 10)
                {
                    dtProdukSimpan.Rows[j][0] = kode + "00" + (code);
                }
                else if (code < 100)
                {
                    dtProdukSimpan.Rows[j][0] = kode + "0" + (code);
                }
                else
                {
                    dtProdukSimpan.Rows[j][0] = kode + (code);
                }
                a = false;
                dataGridView1.ClearSelection();
                tb_namaproduk.Text = "";
                tb_hargaproduk.Text = "";
                tb_stok.Text = "";
                cb_cat.Text = "";
                dataGridView2.ClearSelection();
                tb_addCategory.Text = "";
                cb_filter.Text = "";
            }
        }

        private void cb_filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            tb_namaproduk.Text = "";
            tb_hargaproduk.Text = "";
            tb_stok.Text = "";
            cb_cat.Text = "";
            filter.Rows.Clear();
            dataGridView3.Visible = true;
            dataGridView1.Visible = false;
            a = false;
            c = false;
            string index = "";
            for (int i = 0;i < dtCategory.Rows.Count;i++)
            {
                if (cb_filter.SelectedItem == dtCategory.Rows[i][1])
                {
                    index = dtCategory.Rows[i][0].ToString();
                }
            }
            
            for (int i = 0; i < dtProdukSimpan.Rows.Count;i++)
            {
                if (dtProdukSimpan.Rows[i][4].ToString() ==  index)
                {
                    filter.Rows.Add(dtProdukSimpan.Rows[i][0], dtProdukSimpan.Rows[i][1], dtProdukSimpan.Rows[i][2], dtProdukSimpan.Rows[i][3], dtProdukSimpan.Rows[i][4]);
                }
            }
            dataGridView1.ClearSelection();
            dataGridView2.ClearSelection();
            tb_addCategory.Text = "";
            dataGridView3.ClearSelection();
        }

        private void b_all_Click(object sender, EventArgs e)
        {
            a = false;
            tb_namaproduk.Text = "";
            tb_hargaproduk.Text = "";
            tb_stok.Text = "";
            cb_cat.Text = "";
            dataGridView1.ClearSelection();
            dataGridView3.Visible = false;
            dataGridView1.Visible = true;
            cb_filter.Text = "";
            cb_filter.Enabled = false;
            tb_addCategory.Text = "";
            dataGridView2.ClearSelection();
        }

        private void tb_stok_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            a = true;
        }

        private Bitmap MakeTransparent(Bitmap bitmap, Color color, int tolerance)
        {
            Bitmap transparentImage = new Bitmap(bitmap);

            for (int i = transparentImage.Size.Width - 1; i >= 0; i--)
            {
                for (int j = transparentImage.Size.Height - 1; j >= 0; j--)
                {
                    var currentColor = transparentImage.GetPixel(i, j);
                    if (Math.Abs(color.R - currentColor.R) < tolerance &&
                      Math.Abs(color.G - currentColor.G) < tolerance &&
                      Math.Abs(color.B - currentColor.B) < tolerance)
                        transparentImage.SetPixel(i, j, color);
                }
            }
            transparentImage.MakeTransparent(color);
            return transparentImage;
        }

        private void dataGridView2_Click(object sender, EventArgs e)
        {
            c = true;
        }
    }
}